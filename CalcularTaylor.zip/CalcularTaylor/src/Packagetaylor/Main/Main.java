package pakage.taylor;

import Packagetaylor.Taylor;

/**
 * @author Carlos Esteban González Castillo - ID:470995
 *
 */
public class Main
{
    public static void main( String[] args )
    {
       
	Main.TaylorSeno();

    }
}
